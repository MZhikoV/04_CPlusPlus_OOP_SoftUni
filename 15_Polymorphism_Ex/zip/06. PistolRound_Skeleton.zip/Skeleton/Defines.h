#ifndef DEFINES_H_
#define DEFINES_H_

enum class PistolType
{
	GLOCK		 = 0,
	DESERT_EAGLE = 1
};

enum GeneralDefines
{
	PLAYER_ONE    = 0,
	PLAYER_TWO    = 1,

	PLAYERS_COUNT = 2
};


#endif /* DEFINES_H_ */
