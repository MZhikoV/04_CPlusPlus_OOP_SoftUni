#ifndef ORDERED_INSERTERR_H 
#define ORDERED_INSERTERR_H

#include "Company.h"

#include <vector>
#include <algorithm>


class VectorIdComparer {
        private:
        int searchId;
    public:
    VectorIdComparer(int searchId): searchId(searchId) {};

    bool operator()(const Company* other) const {
        return other->getId()>searchId;
    };
};



class OrderedInserter {

std::vector<const Company*> & companies;

public:
    OrderedInserter(std::vector<const Company*> & companies ) : companies(companies) {};

    void insert(const Company* c) {

        VectorIdComparer a(c->getId());

        std::vector<const Company*>::iterator itFound=find_if(companies.begin(), companies.end(), a);

        companies.insert(itFound,c);



        // struct findData {
        //     int searchId;
        //     findData(int searchId): searchId(searchId) {};

        //     bool operator()(const Company* other) {
        //         return other->getId()>searchId;
        //     };
        // }
    };
         
};




#endif // !ORDERED_INSERTER_H
