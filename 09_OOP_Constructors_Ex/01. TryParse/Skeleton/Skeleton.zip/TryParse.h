#ifndef TRYPARSE_H
#define TRYPARSE_H

#include <string>
#include <cctype>

     bool tryParse (const std::string & a, int & b);
   
#endif