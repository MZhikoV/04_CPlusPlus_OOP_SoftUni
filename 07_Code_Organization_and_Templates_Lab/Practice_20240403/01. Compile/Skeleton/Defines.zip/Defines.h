#ifndef DEFINES_H
#define DEFINES_H


#define STANDARD_TEMPLATE_LIBRARY namespace std;
#include <iostream>
#include <string>

#define DONT_COMPILE_THIS


#endif