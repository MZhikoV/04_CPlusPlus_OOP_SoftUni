#ifndef DONT_COMPILE_THIS
#define DONT_COMPILE_THIS

#define STANDARD_TEMPLATE_LIBRARY namespace std;
#include <iostream>
#include <string> 


#endif