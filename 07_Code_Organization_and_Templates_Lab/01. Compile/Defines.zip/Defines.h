#define DONT_COMPILE_THIS

#define STANDARD_TEMPLATE_LIBRARY namespace std

#ifndef DEFINES_H
#define DEFINES_H

#include <iostream>
#include <string>
#include <sstream>
#include <map>
#include <set>
#include <vector>
#include <algorithm>
#include <queue>
#include <stack>

//using namespace std;



#endif //!DEFINES_H
