#ifndef input_h
#define input_h

#include <string>
#include <map>
#include <iostream>
#include <sstream>

using namespace std;


template <typename T> void read( map<size_t, T> & books, istream & istr) {
       string input;
       while (istr>>input && input!="end") {
       size_t currID=stoi(input);
       istr.ignore();

       T currBook (currID,istr);

       books[currID]=currBook;
       };
};



template <typename T> void print( T book, ostream & ostr) {

ostr<<"book"<<book->getId()<<" \""<<book->getTitle()<<"\" by "<<book->getAuthor()<<" is ";
if (book->getBorrower()=="") {
    ostr<<"\"available\"";
}
else {
    ostr<<"\"borrowed by "<<book->getBorrower()<<"\"";
}
ostr<<endl;
//todo

};

template <typename T> void borrow(  T & book, const string & borrower) {

    book.setBorrowed(borrower);
    print (book,cout);

};

template <typename T> void borrow(  T & book) {
    book.setBorrowed("");
    print (book,cout);

//todo

};

template <typename Tmap> void print( map<size_t, Tmap> * books, ostream & ostr) {
    ostr<<"-----"<<endl;
    ostr<<"total books: "<<books.size();

    for (size_t idx=0; idx<books.size(); idx++) {
        print (books[idx],ostr);
    };

//todo

};


//print<map<size_t, Book> *>(&books, cout)


/*
print<Book>(books[bookID], cout);
print<map<size_t, Book> *>(&books, cout);
*/



#endif