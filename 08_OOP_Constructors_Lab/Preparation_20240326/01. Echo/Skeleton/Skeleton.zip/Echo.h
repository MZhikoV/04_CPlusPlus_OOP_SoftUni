#ifndef ECHO_H
#define ECHO_H

#include <iostream>
#include <string>

extern bool echoOn;

void echo(const std::string & outp);

#endif