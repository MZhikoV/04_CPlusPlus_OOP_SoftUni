#ifndef ECHOO_H
#define ECHOO_H

#include <iostream>

extern bool echoOn;

void echo(const std::string & input);



#endif