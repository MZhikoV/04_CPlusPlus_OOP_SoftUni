#ifndef APPLICATION_H_
#define APPLICATION_H_

class Application {
public:
  void someAwesomeMethod();
};

#endif /* APPLICATION_H_ */
